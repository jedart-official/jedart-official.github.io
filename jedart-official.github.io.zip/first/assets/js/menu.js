$(document).ready(function(){
    $(".burger-menu").click(function(event) {
        $(".burger-header").toggleClass("hide")
        $(".burger-menu").toggleClass("active")

        
        


    })
});